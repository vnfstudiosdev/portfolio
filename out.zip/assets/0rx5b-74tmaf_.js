(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,67821,e=>{"use strict";var t=e.i(43476),a=e.i(71645);let o={grid:0,hex:1,spiral:2,scatter:3},r=Math.PI*(3-Math.sqrt(5)),l=`#version 300 es
precision highp float;
layout(location = 0) in vec4 aDot;
uniform vec2 uSize;
uniform float uPixel;
uniform float uRadius;
uniform float uCell;
uniform vec4 uLens;
uniform vec2 uWarp;
uniform vec3 uGlow;
uniform vec3 uFrom;
uniform vec3 uTo;
uniform vec4 uGlowColor;
uniform vec3 uGradient;
uniform float uTime;
uniform float uWave;
uniform float uSparkle;
uniform float uFocus;
uniform float uBase;
uniform float uLight;
out vec2 vLocal;
out float vRadius;
out float vBlur;
out float vHalo;
out float vHaloWidth;
out vec3 vColor;
out float vAlpha;

vec3 toRgb(vec3 lab) {
  float l = lab.x + 0.3963377774 * lab.y + 0.2158037573 * lab.z;
  float m = lab.x - 0.1055613458 * lab.y - 0.0638541728 * lab.z;
  float s = lab.x - 0.0894841775 * lab.y - 1.291485548 * lab.z;
  vec3 lms = vec3(l * l * l, m * m * m, s * s * s);
  vec3 lin = clamp(vec3(
    4.0767416621 * lms.x - 3.3077115913 * lms.y + 0.2309699292 * lms.z,
    -1.2684380046 * lms.x + 2.6097574011 * lms.y - 0.3413193965 * lms.z,
    -0.0041960863 * lms.x - 0.7034186147 * lms.y + 1.707614701 * lms.z
  ), 0.0, 1.0);
  return mix(lin * 12.92, 1.055 * pow(lin, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, lin));
}

vec3 blend(vec3 a, vec3 b, float t) {
  vec2 ab = mix(a.yz, b.yz, t);
  float chroma = mix(length(a.yz), length(b.yz), t);
  float len = length(ab);
  return vec3(mix(a.x, b.x, t), len > 1e-5 ? ab * (chroma / len) : ab);
}

vec3 wave(vec2 p, float t) {
  float ay = p.x * 0.018 + t + 1.1 * sin(p.y * 0.016 - t * 0.4);
  float ax = p.y * 0.021 + t * 0.7 + 1.3 * sin(p.x * 0.013 + t * 0.3);
  float spread = cos(ay) * 0.0176 * cos(p.y * 0.016 - t * 0.4) + 0.5 * cos(ax) * 0.0169 * cos(p.x * 0.013 + t * 0.3);
  return uWave * vec3(0.5 * sin(ax), sin(ay), spread);
}

void main() {
  vec2 corner = vec2(float(gl_VertexID & 1), float(gl_VertexID >> 1)) * 2.0 - 1.0;
  vec2 center = uSize * 0.5;
  vec3 swell = wave(aDot.xy, uTime);
  vec2 source = center + (aDot.xy - center) * mix(1.12, 1.0, uFocus) + swell.xy;

  vec2 rel = source - uLens.xy;
  float x = length(rel) / uLens.z;
  float y = clamp(1.0 - x * x, 0.0, 1.0);
  float w = y * y * y;
  float k = uWarp.x * uLens.w;
  float grow = 1.0 + k * w;
  float spread = 1.0 + k * (w - 6.0 * x * x * y * y);
  float theta = uWarp.y * uLens.w * w;
  vec2 turn = vec2(cos(theta), sin(theta));
  vec2 display = uLens.xy + vec2(turn.x * rel.x - turn.y * rel.y, turn.y * rel.x + turn.x * rel.y) * grow;
  float scale = sqrt(max(grow * spread, 0.02));

  float spark = 0.0;
  if (uSparkle > 0.0) {
    float phase = 0.5 + 0.5 * sin(uTime * (0.55 + aDot.w * 0.9) + aDot.z * 6.2831853);
    spark = pow(phase, 48.0) * step(0.72, fract(aDot.z * 7.31 + aDot.w * 3.17)) * uSparkle;
  }

  float pool = 0.0;
  if (uGlow.x > 0.0) {
    float g = length(display - uLens.xy) / uGlow.x;
    float q = clamp(1.0 - g * g, 0.0, 1.0);
    pool = q * q * uGlow.y * uLens.w;
  }

  float radius = uRadius * (1.0 + 0.7 * spark);
  float device = radius * scale * uPixel;
  float fade = 1.0;
  if (device < 0.75) {
    fade = device * device / 0.5625;
    radius = 0.75 / (scale * uPixel);
  }
  float blur = (1.0 - uFocus) * uCell * 0.42;
  float energy = pow(radius / (radius + blur), 1.15);
  float halo = pool * uGlow.z;
  float haloWidth = 2.0 + radius * 1.5;
  float pad = radius + blur * 1.2 + 1.5 / (scale * uPixel) + (halo > 0.0 ? haloWidth * 2.5 : 0.0);

  float t = clamp(dot(aDot.xy - center, uGradient.xy) / uGradient.z + 0.5, 0.0, 1.0);
  vec3 tone = blend(uFrom, uTo, t);
  vec3 deep = vec3(tone.x * 0.72, tone.yz * 1.3);
  vec3 base = toRgb(tone);
  vec3 lit = toRgb(mix(deep, uGlowColor.xyz, uGlowColor.w));
  vec3 color = mix(base, lit, clamp(pool, 0.0, 1.0) * 0.8);
  color = mix(color, uLight > 0.5 ? color * 0.6 : vec3(1.0), spark * 0.55);

  vLocal = corner * pad;
  vRadius = radius + blur;
  vBlur = blur * 0.7;
  vHalo = halo;
  vHaloWidth = haloWidth;
  vColor = color;
  float shade = clamp(1.0 - swell.z * 2.5, 0.4, 1.6);
  vAlpha = mix(min(uBase * shade, 1.0), 1.0, clamp(max(pool, spark), 0.0, 1.0)) * fade * energy * smoothstep(0.0, 0.25, uFocus + 0.08);
  vec2 point = display + corner * pad * scale;
  gl_Position = vec4(point.x / uSize.x * 2.0 - 1.0, 1.0 - point.y / uSize.y * 2.0, 0.0, 1.0);
}`,i=`#version 300 es
precision highp float;
uniform float uOpacity;
in vec2 vLocal;
in float vRadius;
in float vBlur;
in float vHalo;
in float vHaloWidth;
in vec3 vColor;
in float vAlpha;
out vec4 fragColor;

void main() {
  float dist = length(vLocal);
  float d = dist - vRadius;
  float edge = max(fwidth(dist), 1e-4) + vBlur;
  float cover = 1.0 - smoothstep(-0.5 * edge, 0.5 * edge, d);
  float glow = vHalo * exp(-max(d, 0.0) / vHaloWidth) * 0.5;
  float alpha = min(cover + glow, 1.0) * vAlpha * uOpacity;
  if (alpha < 0.002) discard;
  fragColor = vec4(vColor * alpha, alpha);
}`,n=(e,t,a)=>Math.min(a,Math.max(t,e)),s=e=>{let t=String(e||"").trim(),a=/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(t);if(a){let e=3===a[1].length?a[1].replace(/./g,e=>e+e):a[1];return[0,2,4].map(t=>parseInt(e.slice(t,t+2),16)/255)}let o=/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(t);return o?[o[1],o[2],o[3]].map(e=>n(parseFloat(e)/255,0,1)):null},u=e=>e<=.04045?e/12.92:Math.pow((e+.055)/1.055,2.4),c=e=>{let[t,a,o]=e.map(u),r=Math.cbrt(.4122214708*t+.5363325363*a+.0514459929*o),l=Math.cbrt(.2119034982*t+.6806995451*a+.1073969566*o),i=Math.cbrt(.0883024619*t+.2817188376*a+.6299787005*o);return[.2104542553*r+.793617785*l-.0040720468*i,1.9779984951*r-2.428592205*l+.4505937099*i,.0259040371*r+.7827717662*l-.808675766*i]},d=(e,t,a)=>{let o=c(s(e)||t);if(!a)return o;let r=n(1-Math.abs(180*Math.atan2(o[2],o[1])/Math.PI-85)/40,0,1),l=.6+.16*r*r*(3-2*r);if(o[0]<=l)return o;let i=1+(o[0]-l)*1.6;return[l,o[1]*i,o[2]*i]},f=(e,t,a)=>{let o=Math.imul(e,0x165667b1)+Math.imul(t,0x27d4eb2f)+Math.imul(a,0x4bf19f61)|0;return o=Math.imul(o^o>>>13,0x4bf19f61),((o^=o>>>16)>>>0)/0x100000000},h=(e,t,a)=>{let o=e.createShader(t);return o?(e.shaderSource(o,a),e.compileShader(o),e.getShaderParameter(o,e.COMPILE_STATUS))?o:(console.error(e.getShaderInfoLog(o)),e.deleteShader(o),null):null};e.s(["default",0,({dotRadius:e=1.5,dotSpacing:u=14,pattern:m="grid",gradientFrom:v="#444444",gradientTo:p="#969696",gradientAngle:x=135,cursorRadius:g=240,bulgeStrength:w=.6,twist:y=0,glowColor:b="#ffffff",glowRadius:M=160,glowIntensity:R=.8,baseOpacity:L=.55,waveAmplitude:A=0,sparkle:S=!1,speed:E=1,interactive:z=!0,holdToZoom:P=!0,intro:C=!0,lightMode:T=!1,opacity:F=1,maxDevicePixelRatio:I=2,className:B="",style:_})=>{let D,W=(0,a.useRef)(null),k=(0,a.useRef)(null),G=(0,a.useRef)(null),[O,q]=(0,a.useState)(0),U=n(e,.25,12),H=2*U+n(u,1,200),N=x*Math.PI/180,V={radius:U,step:H,pattern:o[m]??o.grid,from:d(v,[.32,.15,1],T),to:d(p,[1,.62,.99],T),glowColor:d(b,[1,1,1],T),glowWeight:T?n((Math.hypot((D=c(s(b)||[1,1,1]))[1],D[2])-.02)/.06,0,1):1,direction:[Math.sin(N),-Math.cos(N)],lensRadius:n(g,20,2e3),strength:n(w,-1,1),twist:n(y,-360,360)*Math.PI/180,glowRadius:Math.max(0,M),glowIntensity:n(R,0,2),base:n(L,0,1),wave:n(A,0,60),sparkle:+!!S,speed:Math.max(0,E),interactive:z,holdToZoom:P,intro:C,light:T,opacity:n(F,0,1),maxRatio:n(I,.5,3)},$=(0,a.useRef)(V);return(0,a.useEffect)(()=>{$.current=V,G.current?.()}),(0,a.useEffect)(()=>{let e=W.current,t=k.current;if(!e||!t)return;let a=t.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1,depth:!1,stencil:!1,powerPreference:"high-performance"}),s=a?(e=>{let t=h(e,e.VERTEX_SHADER,l),a=h(e,e.FRAGMENT_SHADER,i),o=t&&a?e.createProgram():null;if(!t||!a||!o)return t&&e.deleteShader(t),a&&e.deleteShader(a),null;if(e.attachShader(o,t),e.attachShader(o,a),e.linkProgram(o),e.deleteShader(t),e.deleteShader(a),!e.getProgramParameter(o,e.LINK_STATUS))return console.error(e.getProgramInfoLog(o)),e.deleteProgram(o),null;let r={},n=e.getProgramParameter(o,e.ACTIVE_UNIFORMS);for(let t=0;t<n;t++){let a=e.getActiveUniform(o,t);a&&(r[a.name]=e.getUniformLocation(o,a.name))}return{program:o,uniforms:r}})(a):null;if(!a||!s)return;let u=window.matchMedia("(prefers-reduced-motion: reduce)").matches,c=a.createVertexArray(),d=a.createBuffer();a.bindVertexArray(c),a.bindBuffer(a.ARRAY_BUFFER,d),a.enableVertexAttribArray(0),a.vertexAttribPointer(0,4,a.FLOAT,!1,16,0),a.vertexAttribDivisor(0,1),a.bindVertexArray(null);let m={width:1,height:1,ratio:1},v={x:0,y:0,inside:!1,down:!1},p={x:0,y:0,vx:0,vy:0,presence:0,zoom:0,ready:!1},x="",g=0,w=100*Math.random(),y=$.current.intro&&!u&&0===O?0:1,b=0,M=0,R=!0,L="hidden"!==document.visibilityState,A=!1,S=(e,t)=>n((e.strength>=0?1.2*e.strength:.7*e.strength)*(1+.6*t),-.85,1.45),E=()=>{let l=$.current,i=e.getBoundingClientRect(),n=Math.max(1,i.width),s=Math.max(1,i.height),u=Math.min(window.devicePixelRatio||1,l.maxRatio,Math.sqrt(9e6/(n*s))),c=Math.max(1,Math.round(n*u)),h=Math.max(1,Math.round(s*u));(t.width!==c||t.height!==h)&&(t.width=c,t.height=h),m.width=n,m.height=s,m.ratio=c/n,(()=>{let e=$.current,t=Math.ceil(((e,t,a)=>{let o=0;for(let r=1;r<48;r++){let l=r/48,i=(1-l*l)**3,n=l*e,s=1+t*i,u=a*i;o=Math.max(o,Math.hypot(n*(s*Math.cos(u)-1),n*s*Math.sin(u)))}return o})(e.lensRadius,S(e,+!!e.holdToZoom),e.twist*(e.holdToZoom?1.6:1))+e.wave+2*e.step),l=(m.width+2*t)*(m.height+2*t),i=Math.max(e.step,Math.sqrt(l/12e4)),n=`${m.width}|${m.height}|${i}|${e.pattern}|${t}`;if(n===x)return;x=n;let s=((e,t,a,l,i)=>{let n=e/2,s=t/2,u=-i,c=e+i,d=-i,h=t+i,m=[],v=(e,t,a,o)=>{e>=u&&e<=c&&t>=d&&t<=h&&m.push(e,t,a,o)};if(l===o.spiral){let o=a/Math.sqrt(Math.PI),l=Math.ceil((Math.hypot(e/2+i,t/2+i)/o)**2);for(let e=0;e<l;e++){let t=o*Math.sqrt(e+.5),a=e*r;v(n+t*Math.cos(a),s+t*Math.sin(a),f(e,0,3),f(e,0,4))}}else{let r=l===o.hex?a*Math.sqrt(3)/2:a,u=Math.ceil((e/2+i)/a)+1,c=Math.ceil((t/2+i)/r)+1;for(let e=-c;e<=c;e++)for(let t=-u;t<=u;t++){let i=n+t*a+(l===o.hex&&1&e?a/2:0),u=s+e*r;l===o.scatter&&(i+=(f(t,e,1)-.5)*a*.8,u+=(f(t,e,2)-.5)*a*.8),v(i,u,f(t,e,3),f(t,e,4))}}return new Float32Array(m)})(m.width,m.height,i,e.pattern,t);g=s.length/4,a.bindBuffer(a.ARRAY_BUFFER,d),a.bufferData(a.ARRAY_BUFFER,s,a.STATIC_DRAW)})()},z=e=>{if(b=0,A)return;let o=$.current,r=n((e-M)/1e3||0,0,.05);M=Math.max(M,e),u||(w+=r*o.speed),y<1&&(y=Math.min(1,y+r/1.8));let l=o.interactive&&v.inside;if(l&&(!p.ready||p.presence<.01)&&(p.x=v.x,p.y=v.y,p.vx=0,p.vy=0,p.ready=!0),p.ready){let e=1+2*r*18,t=324*r,a=r*t,o=1/(e+a),l=(e*p.x+r*p.vx+a*v.x)*o,i=(e*p.y+r*p.vy+a*v.y)*o;p.vx=(p.vx+t*(v.x-p.x))*o,p.vy=(p.vy+t*(v.y-p.y))*o,p.x=l,p.y=i}let i=+!!l;p.presence+=(i-p.presence)*(1-Math.exp(-r/(l?.18:.4)));let d=l&&v.down&&o.holdToZoom?1:0;p.zoom+=(d-p.zoom)*(1-Math.exp(-r/.14));let f=y<.5?4*y*y*y:1-Math.pow(-2*y+2,3)/2,h=p.presence*p.presence*(3-2*p.presence),x=Math.abs(m.width*o.direction[0])+Math.abs(m.height*o.direction[1]);a.viewport(0,0,t.width,t.height),a.clearColor(0,0,0,0),a.clear(a.COLOR_BUFFER_BIT),a.enable(a.BLEND),a.blendFunc(a.ONE,a.ONE_MINUS_SRC_ALPHA),a.useProgram(s.program),a.bindVertexArray(c);let E=s.uniforms;a.uniform2f(E.uSize,m.width,m.height),a.uniform1f(E.uPixel,m.ratio),a.uniform1f(E.uRadius,o.radius),a.uniform1f(E.uCell,o.step),a.uniform4f(E.uLens,p.x,p.y,o.lensRadius*(1+.12*p.zoom),h),a.uniform2f(E.uWarp,S(o,p.zoom),o.twist*(1+.6*p.zoom)),a.uniform3f(E.uGlow,o.glowRadius*(1+.1*p.zoom),o.glowIntensity*(1+.25*p.zoom),+!o.light),a.uniform3f(E.uFrom,o.from[0],o.from[1],o.from[2]),a.uniform3f(E.uTo,o.to[0],o.to[1],o.to[2]),a.uniform4f(E.uGlowColor,o.glowColor[0],o.glowColor[1],o.glowColor[2],o.glowWeight),a.uniform3f(E.uGradient,o.direction[0],o.direction[1],Math.max(x,1)),a.uniform1f(E.uTime,w),a.uniform1f(E.uWave,o.wave),a.uniform1f(E.uSparkle,o.sparkle),a.uniform1f(E.uFocus,f),a.uniform1f(E.uBase,o.light?Math.min(1,1.3*o.base):o.base),a.uniform1f(E.uLight,+!!o.light),a.uniform1f(E.uOpacity,o.opacity),g&&a.drawArraysInstanced(a.TRIANGLE_STRIP,0,4,g);let P=Math.abs(v.x-p.x)+Math.abs(v.y-p.y)>.05||Math.hypot(p.vx,p.vy)>.5,C=Math.abs(i-p.presence)>.002||Math.abs(d-p.zoom)>.002||p.presence>.002&&P,T=!u&&o.speed>0&&(o.wave>0||o.sparkle>0);(y<1||C||T)&&R&&L&&(b=requestAnimationFrame(z))},P=()=>{!b&&!A&&R&&L&&(M=performance.now(),b=requestAnimationFrame(z))};G.current=()=>{E(),P()};let C=t=>{let a=e.getBoundingClientRect();return{x:t.clientX-a.left,y:t.clientY-a.top,inside:t.clientX>=a.left&&t.clientX<=a.right&&t.clientY>=a.top&&t.clientY<=a.bottom}},T=e=>{let t=C(e);v.x=t.x,v.y=t.y,v.inside=t.inside,P()},F=e=>{let t=C(e);v.x=t.x,v.y=t.y,v.inside=t.inside,v.down=t.inside,P()},I=()=>{v.inside=!1,v.down=!1,P()},B=e=>{v.down=!1,"mouse"!==e.pointerType&&(v.inside=!1),P()};window.addEventListener("pointermove",T,{passive:!0}),window.addEventListener("pointerdown",F,{passive:!0}),window.addEventListener("pointerup",B,{passive:!0}),window.addEventListener("pointercancel",B,{passive:!0}),document.documentElement.addEventListener("pointerleave",I);let _=e=>{e.preventDefault(),A=!0,cancelAnimationFrame(b),b=0},D=()=>q(e=>e+1);t.addEventListener("webglcontextlost",_),t.addEventListener("webglcontextrestored",D);let U=new ResizeObserver(()=>{E(),P()});U.observe(e);let H=new IntersectionObserver(e=>{R=e.some(e=>e.isIntersecting),P()});H.observe(e);let N=()=>{L="hidden"!==document.visibilityState,P()};return document.addEventListener("visibilitychange",N),E(),P(),()=>{cancelAnimationFrame(b),G.current=null,U.disconnect(),H.disconnect(),window.removeEventListener("pointermove",T),window.removeEventListener("pointerdown",F),window.removeEventListener("pointerup",B),window.removeEventListener("pointercancel",B),document.documentElement.removeEventListener("pointerleave",I),document.removeEventListener("visibilitychange",N),t.removeEventListener("webglcontextlost",_),t.removeEventListener("webglcontextrestored",D),a.isContextLost()||(a.deleteBuffer(d),a.deleteVertexArray(c),a.deleteProgram(s.program))}},[O]),(0,t.jsx)("div",{ref:W,className:`dot-field${B?` ${B}`:""}`,style:_,children:(0,t.jsx)("canvas",{ref:k,className:"dot-field__canvas","aria-hidden":"true"})})}])},65302,function(e){e.n(e.i(67821))}]);